﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {

        private double numero;

        private string SetNumero
        {
            set
            {
                this.numero = ValidarNumero(value);
            }
        }

        public string BinarioDecimal(string binario)
        {
            if (ValidarNumero(binario) != 0)
            {
                int nroDecimal = 0;
                int i = binario.Length - 1;

                foreach (char item in binario.Substring(0, binario.Length))
                {
                    if (item == '1')
                    {
                        nroDecimal += Convert.ToInt32(Math.Pow(2, i));
                    }
                    i--;
                }

                return nroDecimal.ToString();
            }

            return "Valor inválido";
        }

        public string DecimalBinario(double numero)
        {
            if (ValidarNumero(numero.ToString()) != 0)
            {
                string binarioAlReves = "";
                string binario = "";

                for (int i = Convert.ToInt32(numero); i > 0; i = i / 2)
                {
                    binarioAlReves += i % 2;
                }

                for (int i = binarioAlReves.Length - 1; i >= 0; i--)
                {
                    binario += binarioAlReves[i].ToString();
                }
                return binario;
            }
            return "Valor inválido";
        }

        public string DecimalBinario(string numero)
        {
            if (ValidarNumero(numero) != 0)
            {
                return DecimalBinario(Convert.ToDouble(numero));
            }
            else
            {
                return "Valor inválido";
            }
        }

        public Numero()
        {

        }

        public Numero(double numero)
        {
            this.numero = numero;
        }

        public Numero(string strNumero)
        {
            this.numero = ValidarNumero(strNumero);
        }

        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }

        public static double operator /(Numero n1, Numero n2)
        {
            return n1.numero / n2.numero;
        }

        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }

        private double ValidarNumero(string strNumero)
        {
            int numInt;
            double numDouble;
            if (int.TryParse(strNumero, out numInt))
            {
                return Convert.ToDouble(numInt);
            }
            else if (double.TryParse(strNumero, out numDouble))
            {
                return numDouble;
            }
            return 0;
        }

    }
}
